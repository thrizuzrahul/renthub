import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, MapPin, Clock } from "lucide-react";

const FeaturedRentals = () => {
  const rentals = [
    {
      id: 1,
      title: "Professional DSLR Camera Kit",
      category: "Products",
      price: "$25/day",
      rating: 4.9,
      reviews: 127,
      location: "Downtown",
      image: "https://images.unsplash.com/photo-1606983340126-99ab4feaa64b?w=400&h=300&fit=crop&crop=center",
      available: true
    },
    {
      id: 2,
      title: "Web Development Services",
      category: "Skills",
      price: "$50/hour",
      rating: 5.0,
      reviews: 89,
      location: "Remote",
      image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=400&h=300&fit=crop&crop=center",
      available: true
    },
    {
      id: 3,
      title: "Power Drill Set",
      category: "Products", 
      price: "$15/day",
      rating: 4.7,
      reviews: 203,
      location: "Midtown",
      image: "https://images.unsplash.com/photo-1572981779307-38b8cabb2407?w=400&h=300&fit=crop&crop=center",
      available: true
    },
    {
      id: 4,
      title: "Event Photography",
      category: "Services",
      price: "$200/event", 
      rating: 4.8,
      reviews: 156,
      location: "City Wide",
      image: "https://images.unsplash.com/photo-1554048612-b6ebae92138f?w=400&h=300&fit=crop&crop=center",
      available: false
    }
  ];

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">Featured Rentals</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Discover popular items and services in your area
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {rentals.map((rental) => (
            <Card key={rental.id} className="group hover:shadow-card transition-all duration-300 overflow-hidden border-0 shadow-sm">
              <CardHeader className="p-0">
                <div className="relative">
                  <img
                    src={rental.image}
                    alt={rental.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <Badge 
                    variant="secondary" 
                    className="absolute top-3 left-3 bg-white/90 text-foreground"
                  >
                    {rental.category}
                  </Badge>
                  {!rental.available && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <Badge variant="destructive">Currently Unavailable</Badge>
                    </div>
                  )}
                </div>
              </CardHeader>
              
              <CardContent className="p-4">
                <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                  {rental.title}
                </h3>
                
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 text-accent fill-current" />
                    <span className="text-sm font-medium">{rental.rating}</span>
                    <span className="text-sm text-muted-foreground">({rental.reviews})</span>
                  </div>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <MapPin className="h-3 w-3 mr-1" />
                    {rental.location}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="text-lg font-bold text-primary">
                    {rental.price}
                  </div>
                  <Button 
                    size="sm" 
                    disabled={!rental.available}
                    className="group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
                  >
                    {rental.available ? 'Rent Now' : 'Unavailable'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button size="lg" variant="outline" className="hover:bg-primary hover:text-primary-foreground">
            View All Rentals
          </Button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedRentals;