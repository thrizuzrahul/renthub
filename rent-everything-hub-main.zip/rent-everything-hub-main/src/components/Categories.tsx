import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Wrench, Users, Briefcase, ArrowRight } from "lucide-react";

const Categories = () => {
  const categories = [
    {
      title: "Products",
      description: "Rent physical items from tools to electronics",
      icon: Wrench,
      color: "bg-gradient-primary",
      examples: ["Power Tools", "Cameras", "Furniture", "Sports Equipment"]
    },
    {
      title: "Services",
      description: "Book professional services and expertise",
      icon: Briefcase,
      color: "bg-gradient-secondary",
      examples: ["Photography", "Tutoring", "Consulting", "Repair Services"]
    },
    {
      title: "Skills",
      description: "Access specialized knowledge and abilities",
      icon: Users,
      color: "bg-gradient-hero",
      examples: ["Design", "Writing", "Programming", "Music Lessons"]
    }
  ];

  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">Explore Categories</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Find exactly what you're looking for across our three main rental categories
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {categories.map((category) => (
            <Card key={category.title} className="group hover:shadow-elegant transition-all duration-300 border-0 overflow-hidden">
              <CardHeader className="pb-0">
                <div className={`w-16 h-16 rounded-2xl ${category.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <category.icon className="h-8 w-8 text-white" />
                </div>
                <CardTitle className="text-2xl mb-2">{category.title}</CardTitle>
                <p className="text-muted-foreground">{category.description}</p>
              </CardHeader>
              
              <CardContent className="pt-4">
                <div className="space-y-2 mb-6">
                  {category.examples.map((example) => (
                    <div key={example} className="flex items-center text-sm text-muted-foreground">
                      <div className="w-1 h-1 bg-primary rounded-full mr-3" />
                      {example}
                    </div>
                  ))}
                </div>
                
                <Button variant="ghost" className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                  Explore {category.title}
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform duration-300" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Categories;