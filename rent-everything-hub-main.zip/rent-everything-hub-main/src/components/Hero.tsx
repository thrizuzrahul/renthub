import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import heroImage from "@/assets/hero-marketplace.jpg";

const Hero = () => {
  return (
    <section className="relative py-20 overflow-hidden">
      <div 
        className="absolute inset-0 bg-gradient-hero opacity-90"
        style={{
          backgroundImage: `linear-gradient(135deg, rgba(59, 130, 246, 0.9), rgba(16, 185, 129, 0.9)), url(${heroImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />
      
      <div className="relative container mx-auto px-4 text-center text-white">
        <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
          Rent Anything,
          <br />
          <span className="text-accent">Anywhere</span>
        </h1>
        
        <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto opacity-90">
          Discover services, products, and skills from your community. 
          From power tools to professional expertise - find what you need when you need it.
        </p>

        <div className="max-w-2xl mx-auto mb-8">
          <div className="flex gap-2 bg-white/10 backdrop-blur-sm rounded-lg p-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/70 h-5 w-5" />
              <Input
                placeholder="What would you like to rent?"
                className="pl-10 border-0 bg-transparent text-white placeholder:text-white/70 focus:ring-2 focus:ring-white/30"
              />
            </div>
            <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold">
              Search
            </Button>
          </div>
        </div>

        <div className="flex flex-wrap justify-center gap-4 text-sm">
          <span className="bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full">Photography Equipment</span>
          <span className="bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full">Professional Services</span>
          <span className="bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full">Power Tools</span>
          <span className="bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full">Event Supplies</span>
        </div>
      </div>
    </section>
  );
};

export default Hero;